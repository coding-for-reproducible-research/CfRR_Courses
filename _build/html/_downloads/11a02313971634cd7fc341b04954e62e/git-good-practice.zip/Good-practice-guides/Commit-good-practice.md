# Best practice when committing

## Commit messages

[Good commit messages](https://chris.beams.io/posts/git-commit/)
start with a brief (usually < 50 characters) summary statement about the
changes made in the commit, with more explanation given in a new paragraph if
required. Generally, the summary should complete the sentence "If applied, this
commit will [_commit message here_]".

Avoid uninformative messages such as "small tweaks" or "updates" — write what
will be useful for others to read.


## Commit little and often

Aim for each commit to capture one conceptual change to your work that
can stand alone. This will make the history of your files' development much easier
to follow.

A good rule of thumb: a commit should capture a change that
you can describe in about 50 characters or fewer, potentially with extra
explanation in the commit message if needed.


## Make sure you know what you're committing

Take care when staging multiple files with e.g. `git add .` that you don't
stage changes you didn't mean to. Always check what you're committing with
`git diff` or `git status`.
