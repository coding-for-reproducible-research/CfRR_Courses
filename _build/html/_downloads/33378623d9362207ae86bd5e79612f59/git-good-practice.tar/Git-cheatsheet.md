# Git Cheatsheet

*Note: run commands from within a Git repository*


## Checking the state of files (do this often!)

`git status` — Checks the state of the working tree in a Git repository.


## Adding / committing changes

`git add <files>` — Stages changes in the `<files>`, ready for committing.

`git commit` — Commit changes to the repository that have been staged with
               `git add`.

`git commit -m "commit message here" — Commit changes to the repository, using
                                       the given commit message


## Viewing repository history

`git log` — Shows the history of commits that have been made.

`git log --oneline` — Show summary commit information, one commit per line.

`git log -n` — Show only the last `n` commits.


## Viewing changes

`git diff <files>` — Show changes to files that have not yet been staged.

`git diff <commit1> <commit2> <files>` — Show the differences in files between
                                         two commits.

`git diff --name-only ...` — Only show the names of files that have changed.


## Specifying multiple files

`git <command> path/to/directory` — Apply `<command>` to all files in and descended
                                    from `path/to/directory`

Examples:

`git add .` — Stage all changes to files in current directory or descended from
              current directory.

`git diff foo/` — Show diffs of all files in directory `foo` or descended from
                  `foo`.
