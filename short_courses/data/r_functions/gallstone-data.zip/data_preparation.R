# This file is made available under the 3-Clause BSD licence:
#
# Copyright 2025, University of Exeter
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# 3. Neither the name of the copyright holder nor the names of its contributors
#    may be used to endorse or promote products derived from this software
#    without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS”
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.




# Prepare gallstone dataset from raw data
# Uses packages: readxl, readr and dplyr

# Read raw data, skipping some columns and renaming others
data <- readxl::read_excel("dataset-uci.xlsx",
                           sheet = "dataset",
                           col_types = c("Gallstone Status" = "numeric",
                                         "Age" = "skip",
                                         "Gender" = "skip",
                                         "Comorbidity" = "skip",
                                         "Coronary Artery Disease (CAD)" = "skip",
                                         "Hypothyroidism" = "skip",
                                         "Hyperlipidemia"  = "skip",
                                         "Diabetes Mellitus (DM)" = "numeric",
                                         "Height" = "skip",
                                         "Weight" = "skip",
                                         "Body Mass Index (BMI)" = "numeric",
                                         "Total Body Water (TBW)" = "numeric",
                                         "Extracellular Water (ECW)" = "numeric",
                                         "Intracellular Water (ICW)" = "numeric",
                                         "Extracellular Fluid/Total Body Water (ECF/TBW)" = "skip",
                                         "Total Body Fat Ratio (TBFR) (%)" = "numeric",
                                         "Lean Mass (LM) (%)" = "numeric",
                                         "Body Protein Content (Protein) (%)" = "numeric",
                                         "Visceral Fat Rating (VFR)" = "numeric",
                                         "Bone Mass (BM)" = "numeric",
                                         "Muscle Mass (MM)" = "numeric",
                                         "Obesity (%)" = "skip",
                                         "Total Fat Content (TFC)" = "numeric",
                                         "Visceral Fat Area (VFA)" = "skip",
                                         "Visceral Muscle Area (VMA) (Kg)" = "skip",
                                         "Hepatic Fat Accumulation (HFA)" = "numeric",
                                         "Glucose" = "numeric",
                                         "Total Cholesterol (TC)" = "numeric",
                                         "Low Density Lipoprotein (LDL)" = "skip",
                                         "High Density Lipoprotein (HDL)" = "skip",
                                         "Triglyceride" = "numeric",
                                         "Aspartat Aminotransferaz (AST)" = "numeric",
                                         "Alanin Aminotransferaz (ALT)" = "numeric",
                                         "Alkaline Phosphatase (ALP)" = "skip",
                                         "Creatinine" = "numeric",
                                         "Glomerular Filtration Rate (GFR)" = "skip",
                                         "C-Reactive Protein (CRP)" = "numeric",
                                         "Hemoglobin (HGB)" = "skip",
                                         "Vitamin D" = "skip")) |>
  dplyr::rename(Gallstone_status = "Gallstone Status",
                Diabetes = "Diabetes Mellitus (DM)",
                BMI = "Body Mass Index (BMI)",
                Total_body_water = "Total Body Water (TBW)",
                Extracellular_water = "Extracellular Water (ECW)",
                Intracellular_water = "Intracellular Water (ICW)",
                Total_body_fat_pct = "Total Body Fat Ratio (TBFR) (%)",
                Lean_mass_pct = "Lean Mass (LM) (%)",
                Body_protein_content_pct = "Body Protein Content (Protein) (%)",
                Visceral_fat_rating = "Visceral Fat Rating (VFR)",
                Bone_mass = "Bone Mass (BM)",
                Muscle_mass = "Muscle Mass (MM)",
                Total_fat_content = "Total Fat Content (TFC)",
                Hepatic_fat_accumulation = "Hepatic Fat Accumulation (HFA)",
                Total_cholesterol = "Total Cholesterol (TC)",
                Aspartat_aminotransferaz = "Aspartat Aminotransferaz (AST)",
                Alanin_aminotransferaz = "Alanin Aminotransferaz (ALT)",
                C_reactive_protein = "C-Reactive Protein (CRP)")

# Assign missing values to BMI randomly (approx 5% missing values)
set.seed(42)
data <- data |>
  dplyr::mutate(BMI_missing = (rbinom(n = nrow(data), size = 1, prob = 0.05) == 1)) |>
  dplyr::mutate(BMI = dplyr::if_else(BMI_missing, NA, BMI)) |>
  dplyr::select(-BMI_missing)

# Write to file
data |>
  readr::write_csv("gallstone.csv", na = "")
