## Gallstone data

Date: 2025-07-23

The data `gallstone.csv` is derived from:

Esen, I., Arslan, H., Aktürk, S., Gülşen, M., Kültekin, N., & Özdemir, O. (2024).
Gallstone \[Dataset\]. UCI Machine Learning Repository.
[https://doi.org/10.1097/md.0000000000037258](https://doi.org/10.1097/md.0000000000037258).

The original data is licensed under a
[Creative Commons Attribution 4.0 International licence](https://creativecommons.org/licenses/by/4.0/)
and you can [download it from the UC Irvine Machine Learning Repository](https://archive.ics.uci.edu/dataset/1150/gallstone-1).
It was accessed on 2025-07-23 (saved to the `dataset-uci.xlsx` file in this
archive).

The data `gallstone.csv` is made available under the
[Creative Commons Attribution 4.0 International licence](https://creativecommons.org/licenses/by/4.0/).

`gallstone.csv` only includes a subset of the original columns, which have
been renamed to make them easier to work with in code. We have also randomly
removed some of the body mass index (BMI) values rows in the data, for the
purposes of instruction. It was created using the `data_preparation.R`
script with the package versions defined in `renv.lock`. The direct dependencies
for the script are `readxl`, `readr` and `dplyr`.

The steps for reproducing `gallstone.csv` are as follows:

1. (Optional) Download the original Gallstone dataset from
   <https://archive.ics.uci.edu/static/public/1150/gallstone-1.zip>. Unzip the
   archive and also unzip the `dataset-uci.zip` archive within. Place the Excel
   workbook alongside the `data_preparation.R` script.
2. For reproducibility, ensure the package versions described in `renv.lock` are
   installed (or if you're not worried about that level of reproducibiliy, just
   ensure the direct dependencies given above are installed).
3. Run `data_preparation.R` (in the same directory containing the script). This
   will process the workbook and write the output `gallstone.csv` file.
