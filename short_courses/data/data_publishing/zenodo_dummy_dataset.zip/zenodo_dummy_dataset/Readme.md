# Dummy Environmental Dataset (Zenodo Sandbox Test)

## Overview
This dataset contains **synthetic (dummy) environmental data** representing temperature and relative humidity measurements at ten fictional locations.

The dataset was created solely for **testing data deposit workflows** using the **Zenodo Sandbox**. The values are artificial and do not represent real observations.

## File structure

- `data/temperature_humidity_locations.csv`
  - Main dataset containing temperature and humidity values by location
- `data_dictionary.csv`
  - Description of each variable, including units and allowed values
- `README.md`
  - Documentation describing the dataset and its intended use

## Data description

Each row represents a fictional location (`location_1` to `location_10`).

Variables:
- **Temperature_C**: Synthetic air temperature in degrees Celsius
- **Humidity_percent**: Synthetic relative humidity as a percentage

## Intended use

This dataset is intended for:
- Practising uploads to the Zenodo Sandbox
- Testing metadata entry, licensing, and versioning
- Demonstrating the importance of documentation and metadata

## Licence

This dummy dataset may be shared under a **CC0 (Public Domain Dedication)** or **CC-BY 4.0** licence, as appropriate for testing purposes.

## Notes

Because the data are synthetic, there are no ethical, privacy, or commercial restrictions on reuse.


